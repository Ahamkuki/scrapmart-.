require("dotenv").config();
const express=require("express"), path=require("path"), fs=require("fs");
const Database=require("better-sqlite3");
const multer=require("multer");
const app=express();
const PORT=process.env.PORT||3000;
const db=new Database("scrapmart.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,category TEXT,subcategory TEXT,price REAL,stock REAL,min_qty REAL,location TEXT,description TEXT,image TEXT,active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,customer_name TEXT,mobile TEXT,email TEXT,address TEXT,city TEXT,state TEXT,pincode TEXT,payment TEXT,total REAL,status TEXT DEFAULT 'Order Placed',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS order_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER,product_id INTEGER,qty REAL,rate REAL);
CREATE TABLE IF NOT EXISTS scrap_requests(
 id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,mobile TEXT,whatsapp TEXT,email TEXT,address TEXT,pincode TEXT,city TEXT,scrap_type TEXT,scrap_name TEXT,weight REAL,condition TEXT,description TEXT,pickup_date TEXT,pickup_time TEXT,photos TEXT,status TEXT DEFAULT 'New Request',actual_weight REAL,final_amount REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS rates(id INTEGER PRIMARY KEY AUTOINCREMENT,scrap TEXT UNIQUE,rate REAL);
CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,mobile TEXT,message TEXT,status TEXT DEFAULT 'Open',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
const seed=db.prepare("SELECT COUNT(*) c FROM products").get().c;
if(!seed){
 const ins=db.prepare("INSERT INTO products(name,category,subcategory,price,stock,min_qty,location,description) VALUES(?,?,?,?,?,?,?,?)");
 [["Aluminium Scrap","Aluminium","Mixed Aluminium",120,250,10,"Delhi","Clean aluminium scrap suitable for recycling."],
 ["Copper Scrap","Copper","Millberry/Mixed",680,120,5,"Delhi","Sorted copper scrap."],
 ["Iron Scrap","Iron","Heavy Iron",42,1000,25,"Delhi","Heavy iron scrap."],
 ["PET Plastic Scrap","Plastic","PET",38,600,20,"Delhi","Sorted PET bottles and flakes."],
 ["Cardboard Scrap","Cardboard","Mixed Cardboard",12,1500,25,"Delhi","Dry corrugated cardboard."],
 ["Paper Scrap","Paper","Mixed Paper",16,900,25,"Delhi","Sorted recyclable paper."]].forEach(x=>ins.run(...x));
 const r=db.prepare("INSERT OR IGNORE INTO rates(scrap,rate) VALUES(?,?)");
 [["Aluminium",120],["Copper",680],["Iron",42],["Plastic",38],["Paper",16],["Cardboard",12],["Brass",520]].forEach(x=>r.run(...x));
}
app.use(express.json({limit:"2mb"})); app.use(express.urlencoded({extended:true}));
const uploadDir=path.join(__dirname,"uploads"); if(!fs.existsSync(uploadDir))fs.mkdirSync(uploadDir);
const upload=multer({dest:uploadDir,limits:{fileSize:8*1024*1024}});
app.use("/uploads",express.static(uploadDir)); app.use(express.static(path.join(__dirname,"public")));

app.get("/api/products",(req,res)=>res.json(db.prepare("SELECT * FROM products WHERE active=1 ORDER BY id DESC").all()));
app.get("/api/rates",(req,res)=>res.json(db.prepare("SELECT * FROM rates ORDER BY scrap").all()));
app.get("/api/products/:id",(req,res)=>{const x=db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(req.params.id); x?res.json(x):res.status(404).json({error:"Product not found"})});
app.post("/api/orders",(req,res)=>{
 const {customer_name,mobile,email,address,city,state,pincode,payment,total,items}=req.body;
 if(!customer_name||!mobile||!address||!items?.length)return res.status(400).json({error:"Required details missing"});
 const o=db.prepare("INSERT INTO orders(customer_name,mobile,email,address,city,state,pincode,payment,total) VALUES(?,?,?,?,?,?,?,?,?)").run(customer_name,mobile,email,address,city,state,pincode,payment,total);
 const ins=db.prepare("INSERT INTO order_items(order_id,product_id,qty,rate) VALUES(?,?,?,?)");
 for(const i of items)ins.run(o.lastInsertRowid,i.product_id,i.qty,i.rate);
 res.json({ok:true,orderId:"SCRP"+String(o.lastInsertRowid).padStart(5,"0")});
});
app.post("/api/scrap-requests",upload.array("photos",6),(req,res)=>{
 const d=req.body, photos=(req.files||[]).map(f=>"/uploads/"+f.filename).join(",");
 if(!d.name||!d.mobile||!d.scrap_type||!d.weight||!d.address)return res.status(400).json({error:"Required details missing"});
 const x=db.prepare(`INSERT INTO scrap_requests(name,mobile,whatsapp,email,address,pincode,city,scrap_type,scrap_name,weight,condition,description,pickup_date,pickup_time,photos)
 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(d.name,d.mobile,d.whatsapp,d.email,d.address,d.pincode,d.city,d.scrap_type,d.scrap_name,d.weight,d.condition,d.description,d.pickup_date,d.pickup_time,photos);
 res.json({ok:true,requestId:"REQ"+String(x.lastInsertRowid).padStart(5,"0")});
});
app.post("/api/tickets",(req,res)=>{const d=req.body;if(!d.name||!d.mobile||!d.message)return res.status(400).json({error:"Fill all required fields"});const x=db.prepare("INSERT INTO tickets(name,mobile,message) VALUES(?,?,?)").run(d.name,d.mobile,d.message);res.json({ok:true,ticketId:"TKT"+String(x.lastInsertRowid).padStart(5,"0")})});

function auth(req,res,next){
 const h=req.headers.authorization||"";
 if(h!=="Basic "+Buffer.from((process.env.ADMIN_EMAIL||"admin@example.com")+":"+(process.env.ADMIN_PASSWORD||"change-this-strong-password")).toString("base64"))return res.status(401).json({error:"Unauthorized"});
 next();
}
app.get("/api/admin/summary",auth,(req,res)=>res.json({
 orders:db.prepare("SELECT COUNT(*) c FROM orders").get().c,
 sales:db.prepare("SELECT COALESCE(SUM(total),0) s FROM orders").get().s,
 requests:db.prepare("SELECT COUNT(*) c FROM scrap_requests").get().c,
 pending:db.prepare("SELECT COUNT(*) c FROM scrap_requests WHERE status NOT IN ('Picked Up','Payment Completed')").get().c,
 customers:db.prepare("SELECT COUNT(DISTINCT mobile) c FROM orders").get().c
}));
app.get("/api/admin/requests",auth,(req,res)=>res.json(db.prepare("SELECT * FROM scrap_requests ORDER BY id DESC").all()));
app.patch("/api/admin/requests/:id",auth,(req,res)=>{
 const d=req.body; db.prepare("UPDATE scrap_requests SET status=?,actual_weight=COALESCE(?,actual_weight),final_amount=COALESCE(?,final_amount) WHERE id=?").run(d.status,d.actual_weight,d.final_amount,req.params.id);res.json({ok:true});
});
app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.listen(PORT,()=>console.log("ScrapMart running on "+PORT));
